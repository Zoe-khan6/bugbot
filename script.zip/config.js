/* 

 - Created by : Anggazyy
 - Base by : Siputzxx - Ziyo
 - Thanks : RxhL - Alwaysaqio - X Developer
 
 */

const fs = require('fs')
const { color } = require('./lib/myfunc')

global.owner = '628xxxxx'
global.nomerowner = ["628xxxxx"]
global.packname = 'Di Buat Oleh'
global.author = '_Anggazyy Developer_'
global.urldb = ''; // kosongin aja
global.linkfoto = 'https://iili.io/d6eMtv2.md.jpg'
global.namaowner = '_Anggazyy Developer_'
global.idsaluran = '120363301756685796@newsletter'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(color(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
